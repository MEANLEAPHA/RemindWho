/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.3-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: u523916255_remindme
-- ------------------------------------------------------
-- Server version	11.8.3-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `feedback` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedback`
--

/*!40000 ALTER TABLE `feedback` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `feedback` VALUES
(12,'lyly','ly1869468@gmail.com','ewe'),
(12,'lyly','ly1869468@gmail.com','fff'),
(12,'lyly','ly1869468@gmail.com','fff'),
(12,'lyly','ly1869468@gmail.com','thnre'),
(12,'lyly','ly1869468@gmail.com','new'),
(12,'lyly','ly1869468@gmail.com','wqvfew'),
(12,'lyly','ly1869468@gmail.com','wqvfew'),
(12,'lyly','ly1869468@gmail.com','wqvfew'),
(12,'lyly','ly1869468@gmail.com','wqvfew'),
(12,'lyly','ly1869468@gmail.com','wqvfew'),
(12,'lyly','ly1869468@gmail.com','ggg'),
(12,'lyly','ly1869468@gmail.com','something wrong'),
(27,'MeanLeap Ha','meanleapha@gmail.com','hi'),
(27,'MeanLeap Ha','meanleapha@gmail.com','kk'),
(27,'MeanLeap Ha','meanleapha@gmail.com','33'),
(27,'MeanLeap Ha','meanleapha@gmail.com','test'),
(27,'MeanLeap Ha','meanleapha@gmail.com','dd'),
(27,'MeanLeap Ha','meanleapha@gmail.com','j'),
(27,'MeanLeap Ha','meanleapha@gmail.com','last test'),
(13,'bunleap','hormbunleap33@gmail.com','i hate this webapp useless\n\n');
/*!40000 ALTER TABLE `feedback` ENABLE KEYS */;
commit;

--
-- Table structure for table `report`
--

DROP TABLE IF EXISTS `report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `report` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `complain` varchar(250) NOT NULL,
  `report_email` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report`
--

/*!40000 ALTER TABLE `report` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `report` VALUES
(12,'lyly','ly1869468@gmail.com','ff','lll@gmail.com'),
(12,'lyly','ly1869468@gmail.com','hi','leap@gmail.com'),
(27,'MeanLeap Ha','meanleapha@gmail.com','bb','idont@gmail.com'),
(27,'MeanLeap Ha','meanleapha@gmail.com','i got spam by whoever','whoever@gmail.com'),
(27,'MeanLeap Ha','meanleapha@gmail.com','33','dw@gmail.com'),
(27,'MeanLeap Ha','meanleapha@gmail.com','hi','ok@gmail.com'),
(27,'MeanLeap Ha','meanleapha@gmail.com','hh','ok@gmail.com'),
(13,'bunleap','hormbunleap33@gmail.com','i got spam please help','hacker@gmail.com');
/*!40000 ALTER TABLE `report` ENABLE KEYS */;
commit;

--
-- Table structure for table `todo_tasks`
--

DROP TABLE IF EXISTS `todo_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `todo_tasks` (
  `task_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) DEFAULT NULL,
  `member_email` varchar(100) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `task_name` enum('reading','study','work','social','entertainment','business','important','urgent') NOT NULL,
  `toWho` varchar(100) NOT NULL,
  `toEmail` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `deadline_time` datetime DEFAULT NULL,
  `priority` enum('low','medium','high') DEFAULT 'medium',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `start_status` enum('active','inactive') DEFAULT 'inactive',
  `deadline_status` enum('active','inactive') DEFAULT 'inactive',
  `start_alert_sent` tinyint(1) DEFAULT 0,
  `deadline_alert_sent` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`task_id`),
  KEY `member_id` (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=149 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `todo_tasks`
--

/*!40000 ALTER TABLE `todo_tasks` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `todo_tasks` VALUES
(74,12,'ly1869468@gmail.com','fwef','wefwef','social','Friend','meanleapha@gmail.com','2025-06-24 15:10:00','2025-06-24 15:11:00','medium','2025-06-24 08:09:32','active','active',1,1),
(75,12,'ly1869468@gmail.com','latest','please work','work','Friend','meanleapha@gmail.com','2025-06-24 15:13:00','2025-06-24 15:14:00','high','2025-06-24 08:12:07','active','active',1,1),
(76,12,'ly1869468@gmail.com','hell nnaaa','yoo','important','Friend','meanleapha@gmail.com','2025-06-24 15:16:00','2025-06-24 15:17:00','high','2025-06-24 08:15:26','active','active',1,1),
(78,12,'ly1869468@gmail.com','Read Compound Effect','Hola RemindMe user! Please don\'t forget to read book. It provides entertainment, expands knowledge, and can even contribute to a longer, healthier life. ','reading','',NULL,'2025-06-23 10:20:00','2025-06-23 11:20:00','high','2025-06-25 03:20:11','active','active',1,1),
(79,12,'ly1869468@gmail.com','Read The Compound Effect','Hola RemindMe user! Please don\'t forget to read book. It provides entertainment, expands knowledge, and can even contribute to a longer, healthier life.','reading','Friend','RemindMeUser@gmail.com','2025-06-23 10:22:00','2025-06-23 11:22:00','high','2025-06-25 03:22:26','active','active',1,1),
(80,19,'meanleapha@gmail.com','Watch 28 years laters','10 pm at night after finished the homework','entertainment','',NULL,'2025-07-01 22:00:00','2025-07-01 12:00:00','medium','2025-07-01 07:50:47','inactive','inactive',0,0),
(81,19,'meanleapha@gmail.com','Planning the C++ assignment','Maybe HR or school management system. Ok','study','Friend','ly1869468@gmail.com','2025-07-01 22:00:00','2025-07-05 15:00:00','high','2025-07-01 07:52:42','active','active',1,0),
(116,27,'meanleapha@gmail.com','Build Dynamic filter book On Openlibrary','raw code','study','Me',NULL,'2025-07-14 21:17:00','2025-07-14 21:17:00','medium','2025-07-13 14:17:51','inactive','inactive',0,0),
(117,27,'meanleapha@gmail.com','Compound Effect','from page 53 till 75','reading','Me',NULL,'2025-07-14 21:19:00','2025-07-14 21:19:00','high','2025-07-13 14:19:14','inactive','inactive',0,0),
(118,27,'meanleapha@gmail.com','Learning mapping ','on bro code ','study','Me',NULL,'2025-07-24 21:19:00','2025-07-28 21:19:00','high','2025-07-13 14:19:48','inactive','inactive',0,0),
(119,27,'meanleapha@gmail.com','Learn Filter','on bro code yt','study','Me',NULL,'2025-07-15 21:20:00','2025-07-22 21:20:00','high','2025-07-13 14:20:17','inactive','inactive',0,0),
(120,27,'meanleapha@gmail.com','Learn forEach','on brocode yt','study','Me',NULL,'2025-07-21 21:20:00','2025-07-22 21:20:00','high','2025-07-13 14:20:47','inactive','inactive',0,0),
(121,27,'meanleapha@gmail.com','Trading ','take time understand more deeper about the market','work','Me',NULL,'2025-07-13 12:21:00','2025-07-13 21:26:00','high','2025-07-13 14:21:38','inactive','inactive',0,0),
(122,27,'meanleapha@gmail.com','More understanding about The VPS','see how ppl hosting the real web ','important','Me',NULL,'2025-07-24 21:22:00','2025-07-13 12:22:00','medium','2025-07-13 14:22:37','inactive','inactive',0,0),
(140,28,'meanleapha@gmail.com','finished Ui design ','YouTube UI style, just design better','work','Me',NULL,'2025-08-18 06:00:00','2025-08-18 08:40:00','high','2025-08-18 09:22:00','inactive','inactive',0,0),
(141,28,'meanleapha@gmail.com','Awaken the giant with ','On page 72','reading','Me',NULL,'2025-08-18 15:00:00','2025-08-18 16:00:00','high','2025-08-18 09:23:02','inactive','inactive',0,0),
(142,28,'meanleapha@gmail.com','Shopping ','Milk, chicken, peanut butter, chip, indome ','important','Me',NULL,'2025-08-18 10:30:00','2025-08-18 10:40:00','high','2025-08-18 09:24:16','inactive','inactive',0,0),
(143,28,'meanleapha@gmail.com','$POND','take $FUN $45 transfer to Merlin total $135 on trading ','work','Me',NULL,'2025-08-18 13:30:00','2025-08-18 13:50:00','medium','2025-08-18 09:26:38','inactive','inactive',0,0),
(144,28,'meanleapha@gmail.com','API documentation ','Do more research on book api ','study','Me',NULL,'2025-08-18 14:30:00','2025-08-18 15:50:00','high','2025-08-18 09:27:35','inactive','inactive',0,0),
(145,29,'keoplyna123@gmail.com','goon','goon to orihime','study','Me',NULL,'2025-08-25 14:39:00','2025-08-25 14:44:00','medium','2025-08-25 14:39:46','active','active',1,1);
/*!40000 ALTER TABLE `todo_tasks` ENABLE KEYS */;
commit;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `email` varchar(191) NOT NULL,
  `password` varchar(100) NOT NULL,
  `timezone` varchar(100) DEFAULT 'UTC',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `pin_code` varchar(6) DEFAULT NULL,
  `status` enum('unverified','verified') DEFAULT 'unverified',
  `pin_expires_at` datetime DEFAULT NULL,
  `pin_created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

/*!40000 ALTER TABLE `users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `users` VALUES
(1,'userOne','one@gmail.com','$2b$10$qF1uHm0hkYmPxQvBDRBnY.H..z6peWmM0N/Q12DPy3SnSg6WPCNUS','Asia/Bangkok','2025-06-09 03:47:13',NULL,'unverified',NULL,'2025-06-14 14:45:57'),
(2,'two','two@gmail.com','$2b$10$vW6iQHaJrF2rqULEe663vORWEzqa3QncP898f6CAybO7Kv0quAijm','Asia/Bangkok','2025-06-09 05:39:08',NULL,'unverified',NULL,'2025-06-14 14:45:57'),
(3,'three','three@gmail.com','$2b$10$OQxcbX8pmtrWzzap0uUfbuV5GZ6vo32fTa6R1nZP7HVGwuFpPLovO','Asia/Bangkok','2025-06-09 05:41:52',NULL,'unverified',NULL,'2025-06-14 14:45:57'),
(4,'four','four@gmail.com','$2b$10$8J6JiQ54dDReZJMe.qkFMOYI3V3wzJ/N6qRpjZttheO5wPRc13zRm','Asia/Bangkok','2025-06-09 09:34:31',NULL,'unverified',NULL,'2025-06-14 14:45:57'),
(12,'lylysss','ly186946868@gmail.com','$2b$10$Si6.iMsGmt.W8rK9jX8RbuIvTFHuBjbb1imvMKp9OB.4dHrHy8sYW','Asia/Bangkok','2025-06-15 03:54:40',NULL,'verified',NULL,NULL),
(13,'bunleap','hormbunleap33@gmail.com','$2b$10$b57exD8mfWxHkd1J2SMjAONK2FDb/cGMxhogvPVqG.8jf7J/x2ilW','Asia/Bangkok','2025-06-16 02:25:12',NULL,'verified',NULL,NULL),
(20,'bibi','bibssi@gmail.com','$2b$10$1O7iJvTrCS1TMv6ImZFFiOpeQ2Xk3AsQeCTlFYj8PS2OWA0iHh8FO','Asia/Bangkok','2025-06-29 16:48:28','228017','unverified',NULL,'2025-06-29 23:48:28'),
(21,'example@gmail.com','examplenonono@gmail.com','$2b$10$fFI4eQgJ2iSE0Pp2AI83eeZ1eAIdWHrxbXVkqL/z4xo2W6c4YxMHS','Asia/Bangkok','2025-06-29 16:52:34','773653','unverified',NULL,'2025-06-29 23:52:34'),
(22,'gg','ggdouluvme@gmail.com','$2b$10$YYCnCRpFlkLTVG76ltGNDOXF0xehAhnwy3C2NTKgPM8OT6TFAXgGG','Asia/Bangkok','2025-06-29 16:56:06','344232','unverified',NULL,'2025-06-29 23:56:06'),
(23,'example','ex23dd@gmail.com','$2b$10$ywA5f/2x1KAIu2fTPLTQwuNAWGbdY2e2x8SP1gfRzwzjB1YPJEbq2','Asia/Bangkok','2025-06-30 02:03:47','654960','unverified',NULL,'2025-06-30 09:03:47'),
(24,'scace','dsvsds@s8gmail.com','$2b$10$YqwU9EyiLq7WqJ.mHvWDIO7YfviZ3dm2BXje9tj17PYFGne.JaUTy','Asia/Bangkok','2025-06-30 02:08:52','744892','unverified',NULL,'2025-06-30 09:08:52'),
(25,'jjj','kkii887yt@ex.com','$2b$10$e8unzkSUpoX9hXiW2oPZyec7CKxDDA.SxKBTjqYq9OPy.z8YlgF0q','Asia/Bangkok','2025-07-03 03:03:42','771165','unverified',NULL,'2025-07-03 10:03:42'),
(26,'sbxsanc','meanleap','$2b$10$G3mCzFGyNTBI2U6N7p5LueOGylFXw7Y7wpXaJ/EC79N6aYL8iWbfC','Asia/Bangkok','2025-07-03 03:06:57','183243','unverified',NULL,'2025-07-03 10:06:57'),
(28,'meanleapha','meanleapha@gmail.com','$2b$10$gb9nHwngLdBPcaPznf6ed.1BpZNHjf.plWjvRincTQQDWp9r9r/Sm','Asia/Bangkok','2025-07-20 14:37:32',NULL,'verified',NULL,NULL),
(29,'supernigger','keoplyna123@gmail.com','$2b$10$.eYiPIKg2TQJqlw8u8hUte4FcHIkJ6TQcsy0Sxd1yKQXLdTl8SPki','Asia/Phnom_Penh','2025-08-25 14:38:30',NULL,'verified',NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
commit;

--
-- Dumping routines for database 'u523916255_remindme'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2025-11-14 15:45:14
